# Bob-Theme-Argon
Điều chỉnh các chủ đề front-end của v2board v1.5.1 trở lên

Chủ đề này được dịch bởi @AQSaikato.

### Sau khi tải xuống thư mục chủ đề, bạn cần sửa đổi tên thư mục hiện tại thành `bob-argon`, rồi chọn chủ đề bob-argon trong nền.

